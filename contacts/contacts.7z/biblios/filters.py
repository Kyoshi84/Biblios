from django import forms
from django.conf import settings
from .models import Library
import django_filters


class LFilter(django_filters.FilterSet):
	status = django_filters.MultipleChoiceFilter(choices=settings.STATUS_CHOICES, widget=forms.CheckboxSelectMultiple)
	type = django_filters.MultipleChoiceFilter(choices=settings.TYPE_CHOICES, widget=forms.CheckboxSelectMultiple)
	chain = django_filters.MultipleChoiceFilter(choices=settings.CHAIN_CHOICES, widget=forms.CheckboxSelectMultiple)
	state = django_filters.MultipleChoiceFilter(choices=Library.STATE_CHOICES, widget=forms.CheckboxSelectMultiple)
	class  Meta:
		model = Library
		fields = ['status','type', 'chain','state',]