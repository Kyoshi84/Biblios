from django.shortcuts import render, get_object_or_404, redirect
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from django.http import HttpResponse, Http404, HttpResponseRedirect
from django.template import loader
from .models import Library
import django_filters
from .filters import LFilter
# Create your views here.

#def index(request):
 #  return HttpResponse("Hello, world. You're at the contacts index.")


def index(request):
	#full list
	queryset_list = Library.objects.all()
	#search
	query = request.GET.get('q', '')
	if query:
		queryset_list = queryset_list.filter(
			Q(name__icontains=query)|
			Q(phone__icontains=query)|
			Q(url__icontains=query)| 
			Q(email__icontains=query)| 
			Q(owner__icontains=query)
				)#.distinct()
		
	library_list = Library.objects.all()
	library_filter = LFilter(request.GET, queryset=library_list)
	
	#pagination
	paginator = Paginator(queryset_list, 10)
	page_request_var = "page"
	page = request.GET.get(page_request_var)
	try:
		queryset = paginator.page(page)
	except PageNotAnInteger:
		queryset = paginator.page(1)
	except EmptyPage:
		queryset = paginator.page(paginator.num_pages)

	context = {
		"object_list": queryset, 
		"name" : "List",
		"page_request_var": page_request_var,
		"filter": library_filter,
			}
			
	
	return render(request, 'index.html', context)			

def home(request):
	library_list = Library.objects.all()
	library_filter = LFilter(request.GET, queryset=library_list)
	return render(request, 'home.html', {'filter': library_filter})

def contact(request):
	return render(request, "contact.html")	

# to jest zle, do poprawy view dla pojedynczego rekordu
def entity(request, library_id):
	try:
		library = Library.objects.get(pk=library_id)
	except Library.DoesNotExist:
		raise Http404("Biblioteka o takim id nie istnieje")	
	# response = "Wyniki dla bibliotekki %s."
	return render(request, 'entity.html', {'library': library})